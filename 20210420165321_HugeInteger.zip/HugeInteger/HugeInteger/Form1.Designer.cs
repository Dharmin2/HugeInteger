﻿
namespace HugeInteger
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.number2Label = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.number2TextBox = new System.Windows.Forms.TextBox();
            this.isZeroCheckBox = new System.Windows.Forms.CheckBox();
            this.greaterThanCheckBox = new System.Windows.Forms.CheckBox();
            this.lessThanCheckBox = new System.Windows.Forms.CheckBox();
            this.greaterThanOrEqualToCheckBox = new System.Windows.Forms.CheckBox();
            this.lessThanOrEqualToCheckBox = new System.Windows.Forms.CheckBox();
            this.equalToCheckBox = new System.Windows.Forms.CheckBox();
            this.isNotEqualToCheckBox = new System.Windows.Forms.CheckBox();
            this.operationsGroupBox = new System.Windows.Forms.GroupBox();
            this.remainderRadioButton = new System.Windows.Forms.RadioButton();
            this.divideRadioButton = new System.Windows.Forms.RadioButton();
            this.multiplyRadioButton = new System.Windows.Forms.RadioButton();
            this.subtractButton = new System.Windows.Forms.RadioButton();
            this.addRadioButton = new System.Windows.Forms.RadioButton();
            this.confirmButton = new System.Windows.Forms.Button();
            this.answerLabel = new System.Windows.Forms.Label();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.operationsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(161, 54);
            this.numberTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(294, 20);
            this.numberTextBox.TabIndex = 0;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(113, 54);
            this.numberLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(44, 13);
            this.numberLabel.TabIndex = 2;
            this.numberLabel.Text = "Number";
            // 
            // number2Label
            // 
            this.number2Label.AutoSize = true;
            this.number2Label.Location = new System.Drawing.Point(107, 91);
            this.number2Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.number2Label.Name = "number2Label";
            this.number2Label.Size = new System.Drawing.Size(50, 13);
            this.number2Label.TabIndex = 3;
            this.number2Label.Text = "Number2";
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLabel.Location = new System.Drawing.Point(155, 300);
            this.displayLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(2, 15);
            this.displayLabel.TabIndex = 5;
            // 
            // number2TextBox
            // 
            this.number2TextBox.Location = new System.Drawing.Point(161, 89);
            this.number2TextBox.Margin = new System.Windows.Forms.Padding(2);
            this.number2TextBox.Name = "number2TextBox";
            this.number2TextBox.Size = new System.Drawing.Size(294, 20);
            this.number2TextBox.TabIndex = 6;
            // 
            // isZeroCheckBox
            // 
            this.isZeroCheckBox.AutoSize = true;
            this.isZeroCheckBox.Enabled = false;
            this.isZeroCheckBox.Location = new System.Drawing.Point(161, 267);
            this.isZeroCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.isZeroCheckBox.Name = "isZeroCheckBox";
            this.isZeroCheckBox.Size = new System.Drawing.Size(55, 17);
            this.isZeroCheckBox.TabIndex = 11;
            this.isZeroCheckBox.Text = "isZero";
            this.isZeroCheckBox.UseVisualStyleBackColor = true;
            // 
            // greaterThanCheckBox
            // 
            this.greaterThanCheckBox.AutoSize = true;
            this.greaterThanCheckBox.Enabled = false;
            this.greaterThanCheckBox.Location = new System.Drawing.Point(161, 136);
            this.greaterThanCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.greaterThanCheckBox.Name = "greaterThanCheckBox";
            this.greaterThanCheckBox.Size = new System.Drawing.Size(86, 17);
            this.greaterThanCheckBox.TabIndex = 12;
            this.greaterThanCheckBox.Text = "GreaterThan";
            this.greaterThanCheckBox.UseVisualStyleBackColor = true;
            // 
            // lessThanCheckBox
            // 
            this.lessThanCheckBox.AutoSize = true;
            this.lessThanCheckBox.Enabled = false;
            this.lessThanCheckBox.Location = new System.Drawing.Point(161, 158);
            this.lessThanCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.lessThanCheckBox.Name = "lessThanCheckBox";
            this.lessThanCheckBox.Size = new System.Drawing.Size(73, 17);
            this.lessThanCheckBox.TabIndex = 13;
            this.lessThanCheckBox.Text = "LessThan";
            this.lessThanCheckBox.UseVisualStyleBackColor = true;
            // 
            // greaterThanOrEqualToCheckBox
            // 
            this.greaterThanOrEqualToCheckBox.AutoSize = true;
            this.greaterThanOrEqualToCheckBox.Enabled = false;
            this.greaterThanOrEqualToCheckBox.Location = new System.Drawing.Point(161, 180);
            this.greaterThanOrEqualToCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.greaterThanOrEqualToCheckBox.Name = "greaterThanOrEqualToCheckBox";
            this.greaterThanOrEqualToCheckBox.Size = new System.Drawing.Size(137, 17);
            this.greaterThanOrEqualToCheckBox.TabIndex = 14;
            this.greaterThanOrEqualToCheckBox.Text = "GreaterThanOrEqualTo";
            this.greaterThanOrEqualToCheckBox.UseVisualStyleBackColor = true;
            // 
            // lessThanOrEqualToCheckBox
            // 
            this.lessThanOrEqualToCheckBox.AutoSize = true;
            this.lessThanOrEqualToCheckBox.Enabled = false;
            this.lessThanOrEqualToCheckBox.Location = new System.Drawing.Point(161, 202);
            this.lessThanOrEqualToCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.lessThanOrEqualToCheckBox.Name = "lessThanOrEqualToCheckBox";
            this.lessThanOrEqualToCheckBox.Size = new System.Drawing.Size(124, 17);
            this.lessThanOrEqualToCheckBox.TabIndex = 15;
            this.lessThanOrEqualToCheckBox.Text = "LessThanOrEqualTo";
            this.lessThanOrEqualToCheckBox.UseVisualStyleBackColor = true;
            // 
            // equalToCheckBox
            // 
            this.equalToCheckBox.AutoSize = true;
            this.equalToCheckBox.Enabled = false;
            this.equalToCheckBox.Location = new System.Drawing.Point(161, 223);
            this.equalToCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.equalToCheckBox.Name = "equalToCheckBox";
            this.equalToCheckBox.Size = new System.Drawing.Size(66, 17);
            this.equalToCheckBox.TabIndex = 16;
            this.equalToCheckBox.Text = "EqualTo";
            this.equalToCheckBox.UseVisualStyleBackColor = true;
            // 
            // isNotEqualToCheckBox
            // 
            this.isNotEqualToCheckBox.AutoSize = true;
            this.isNotEqualToCheckBox.Enabled = false;
            this.isNotEqualToCheckBox.Location = new System.Drawing.Point(161, 245);
            this.isNotEqualToCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.isNotEqualToCheckBox.Name = "isNotEqualToCheckBox";
            this.isNotEqualToCheckBox.Size = new System.Drawing.Size(91, 17);
            this.isNotEqualToCheckBox.TabIndex = 17;
            this.isNotEqualToCheckBox.Text = "IsNotEqualTo";
            this.isNotEqualToCheckBox.UseVisualStyleBackColor = true;
            // 
            // operationsGroupBox
            // 
            this.operationsGroupBox.Controls.Add(this.remainderRadioButton);
            this.operationsGroupBox.Controls.Add(this.divideRadioButton);
            this.operationsGroupBox.Controls.Add(this.multiplyRadioButton);
            this.operationsGroupBox.Controls.Add(this.subtractButton);
            this.operationsGroupBox.Controls.Add(this.addRadioButton);
            this.operationsGroupBox.Location = new System.Drawing.Point(304, 136);
            this.operationsGroupBox.Margin = new System.Windows.Forms.Padding(2);
            this.operationsGroupBox.Name = "operationsGroupBox";
            this.operationsGroupBox.Padding = new System.Windows.Forms.Padding(2);
            this.operationsGroupBox.Size = new System.Drawing.Size(150, 136);
            this.operationsGroupBox.TabIndex = 18;
            this.operationsGroupBox.TabStop = false;
            this.operationsGroupBox.Text = "Operations";
            // 
            // remainderRadioButton
            // 
            this.remainderRadioButton.AutoSize = true;
            this.remainderRadioButton.Location = new System.Drawing.Point(4, 118);
            this.remainderRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.remainderRadioButton.Name = "remainderRadioButton";
            this.remainderRadioButton.Size = new System.Drawing.Size(76, 17);
            this.remainderRadioButton.TabIndex = 4;
            this.remainderRadioButton.Text = "Remainder";
            this.remainderRadioButton.UseVisualStyleBackColor = true;
            // 
            // divideRadioButton
            // 
            this.divideRadioButton.AutoSize = true;
            this.divideRadioButton.Location = new System.Drawing.Point(4, 97);
            this.divideRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.divideRadioButton.Name = "divideRadioButton";
            this.divideRadioButton.Size = new System.Drawing.Size(55, 17);
            this.divideRadioButton.TabIndex = 3;
            this.divideRadioButton.Text = "Divide";
            this.divideRadioButton.UseVisualStyleBackColor = true;
            // 
            // multiplyRadioButton
            // 
            this.multiplyRadioButton.AutoSize = true;
            this.multiplyRadioButton.Location = new System.Drawing.Point(4, 74);
            this.multiplyRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.multiplyRadioButton.Name = "multiplyRadioButton";
            this.multiplyRadioButton.Size = new System.Drawing.Size(60, 17);
            this.multiplyRadioButton.TabIndex = 2;
            this.multiplyRadioButton.Text = "Multiply";
            this.multiplyRadioButton.UseVisualStyleBackColor = true;
            // 
            // subtractButton
            // 
            this.subtractButton.AutoSize = true;
            this.subtractButton.Location = new System.Drawing.Point(4, 52);
            this.subtractButton.Margin = new System.Windows.Forms.Padding(2);
            this.subtractButton.Name = "subtractButton";
            this.subtractButton.Size = new System.Drawing.Size(65, 17);
            this.subtractButton.TabIndex = 1;
            this.subtractButton.Text = "Subtract";
            this.subtractButton.UseVisualStyleBackColor = true;
            // 
            // addRadioButton
            // 
            this.addRadioButton.AutoSize = true;
            this.addRadioButton.Checked = true;
            this.addRadioButton.Location = new System.Drawing.Point(4, 30);
            this.addRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.addRadioButton.Name = "addRadioButton";
            this.addRadioButton.Size = new System.Drawing.Size(44, 17);
            this.addRadioButton.TabIndex = 0;
            this.addRadioButton.TabStop = true;
            this.addRadioButton.Text = "Add";
            this.addRadioButton.UseVisualStyleBackColor = true;
            // 
            // confirmButton
            // 
            this.confirmButton.Location = new System.Drawing.Point(477, 54);
            this.confirmButton.Margin = new System.Windows.Forms.Padding(2);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(56, 19);
            this.confirmButton.TabIndex = 19;
            this.confirmButton.Text = "Confirm";
            this.confirmButton.UseVisualStyleBackColor = true;
            this.confirmButton.Click += new System.EventHandler(this.confirmButton_Click);
            // 
            // answerLabel
            // 
            this.answerLabel.AutoSize = true;
            this.answerLabel.Location = new System.Drawing.Point(107, 300);
            this.answerLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(45, 13);
            this.answerLabel.TabIndex = 20;
            this.answerLabel.Text = "Answer:";
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(113, 18);
            this.instructionsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(229, 13);
            this.instructionsLabel.TabIndex = 21;
            this.instructionsLabel.Text = "Pick operation Input numbers and Click confirm";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.operationsGroupBox);
            this.Controls.Add(this.isNotEqualToCheckBox);
            this.Controls.Add(this.equalToCheckBox);
            this.Controls.Add(this.lessThanOrEqualToCheckBox);
            this.Controls.Add(this.greaterThanOrEqualToCheckBox);
            this.Controls.Add(this.lessThanCheckBox);
            this.Controls.Add(this.greaterThanCheckBox);
            this.Controls.Add(this.isZeroCheckBox);
            this.Controls.Add(this.number2TextBox);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.number2Label);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.numberTextBox);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "HugeIntegerTestForm";
            this.operationsGroupBox.ResumeLayout(false);
            this.operationsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label number2Label;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.TextBox number2TextBox;
        private System.Windows.Forms.CheckBox isZeroCheckBox;
        private System.Windows.Forms.CheckBox greaterThanCheckBox;
        private System.Windows.Forms.CheckBox lessThanCheckBox;
        private System.Windows.Forms.CheckBox greaterThanOrEqualToCheckBox;
        private System.Windows.Forms.CheckBox lessThanOrEqualToCheckBox;
        private System.Windows.Forms.CheckBox equalToCheckBox;
        private System.Windows.Forms.CheckBox isNotEqualToCheckBox;
        private System.Windows.Forms.GroupBox operationsGroupBox;
        private System.Windows.Forms.RadioButton remainderRadioButton;
        private System.Windows.Forms.RadioButton divideRadioButton;
        private System.Windows.Forms.RadioButton multiplyRadioButton;
        private System.Windows.Forms.RadioButton subtractButton;
        private System.Windows.Forms.RadioButton addRadioButton;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.Label instructionsLabel;
    }
}

