﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HugeInteger
{
    public partial class Form1 : Form
    {
        HugeInteger huge = new HugeInteger();
        HugeInteger huge2 = new HugeInteger();
        public Form1()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            if (addRadioButton.Checked)
            {
                huge.Input(numberTextBox.Text);
                huge2.Input(number2TextBox.Text);
                displayLabel.Text = huge.add(huge2).ToString();
            }
            else if (subtractButton.Checked)
            {
                huge.Input(numberTextBox.Text);
                huge2.Input(number2TextBox.Text);
                displayLabel.Text = huge.subtract(huge2).ToString();
            }

            else if (multiplyRadioButton.Checked)
            {
                huge.Input(numberTextBox.Text);
                huge2.Input(number2TextBox.Text);
                displayLabel.Text = huge.multiply(huge2).ToString();
     
                }

            else if (divideRadioButton.Checked)
            {
                huge.Input(numberTextBox.Text);
                huge2.Input(number2TextBox.Text);
                displayLabel.Text = huge.divide(huge2).ToString();
            }
            else
            {
                huge.Input(numberTextBox.Text);
                huge2.Input(number2TextBox.Text);
                displayLabel.Text = huge.remainder(huge2).ToString();
            }

            if (huge.isGreaterThan(huge2))
            {
                greaterThanCheckBox.Checked = true;
            }
            else
            {
                greaterThanCheckBox.Checked = false;
            }

            if (huge.isLessThan(huge2))
            {
                lessThanCheckBox.Checked = true;
            }
            else
            {
                lessThanCheckBox.Checked = false;
            }

            if (huge.isGreaterThanOrEqualTo(huge2))
            {
                greaterThanOrEqualToCheckBox.Checked = true;
            }
            else
            {
                greaterThanOrEqualToCheckBox.Checked = false;
            }

            if (huge.isLessThanOrEqualTo(huge2))
            {
                lessThanOrEqualToCheckBox.Checked = true;
            }
            else
            {
                lessThanOrEqualToCheckBox.Checked = false;
            }

            if (huge.isEqualTo(huge2))
            {
                equalToCheckBox.Checked = true;
                isNotEqualToCheckBox.Checked = false;
            }
            else
            {
                equalToCheckBox.Checked = false;
                isNotEqualToCheckBox.Checked = true;
            }

            if (huge.isZero())
            {
                isZeroCheckBox.Checked = true;
            }

            else
            {
                isZeroCheckBox.Checked = false;
            }
        }
    }
}
