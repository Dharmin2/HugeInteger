﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HugeInteger
{
    class HugeInteger
    {
        private int[] nums = new int[40];
        public HugeInteger()
        {
            for (int i = 0; i < 40; i++)
            {
                nums[i] = 0;
            }
        }

        public void Input(string str)
        {
            str.TrimStart('0');
            char[] strNums = str.ToCharArray();

            nums = new int[str.Length];
            for (int i = 0; i < str.Length; i++)
            {
                nums[i] = strNums[i] - '0';
            }

        }

        public override string ToString()
        {
            string str = "";

            for (int i = nums.Length - 1; i >= 0; i--)
            {
                str = nums[i] + str;
            }
            return str;
        }

        public HugeInteger multiply(HugeInteger othernum)
        {
            HugeInteger result = new HugeInteger();
            int length = this.nums.Length;
            int length2 = othernum.nums.Length;
            string strNum = this.ToString();
            string strOthernum = othernum.ToString();
            int[] nums = new int[length + length2];
            int index = 0;

            if (this.isZero() || othernum.isZero())
            {
                result.Input("0");
                return result;
            }

            for (int i = length - 1; i >= 0; i--)
            {
                int index2 = 0;
                int carry = 0;
                int digit = strNum[i] - '0';

                for (int j = length2 - 1; j >= 0; j--)
                {
                    int digit2 = strOthernum[j] - '0';
                    int product = digit * digit2 + nums[index + index2] + carry;
                    carry = product / 10;
                    nums[index + index2] = product % 10;
                    index2++;
                }

                if (carry > 0)
                {
                    nums[index + index2] += carry;
                }

                index++;
            }

            index = nums.Length - 1;
            string str = "";

            while (index >= 0)
            {
                str += (nums[index--]);
            }
            str = str.TrimStart('0');
            result.Input(str);
            return result;
        }

        public HugeInteger divide(HugeInteger otherNum)
        {
            HugeInteger count = new HugeInteger(); //Number that is addded to the end of the answer
            HugeInteger huge = new HugeInteger(); //Part of number that is being divided
            HugeInteger result = new HugeInteger(); //Answer
            count.Input("0");
            result.Input("0");
            string ans = "";
            string dividend = this.ToString();
            int index = 1;
            string subDividend = dividend.Substring(0, index);
            huge.Input(subDividend);
            if (this.isLessThan(otherNum))
            {
                return result;
            } 
            do
            {
                if (this.isGreaterThanOrEqualTo(otherNum * result.ToString() + otherNum.ToString()))
                {
                    huge.Input(this.subtract(otherNum * result.ToString()).ToString());
                }
                else
                {
                    break;
                }
                while (huge.isLessThan(otherNum))
                {
                    subDividend = dividend.Substring(0, index++);
                    huge.Input(subDividend);
                }
                while (huge.isGreaterThanOrEqualTo(otherNum))
                {
                    huge = huge.subtract(otherNum);
                    count = count + "1";
                }
                result = (result * "10").add(count);
                index = 1;
                count.Input("0");
                ans = result.ToString();
                if (this.isEqualTo(otherNum * ans))
                {
                    break;
                }
                if (this.ToString().TrimEnd('0').Equals(result.ToString()))
                {
                    int zeros = this.ToString().Length - this.ToString().TrimEnd('0').Length;
                    for (int i = 0; i < zeros; i++)
                    {
                        ans += "0";
                    }
                    result.Input(ans);
                    return result;
                }
            }
            while (true);
            result.Input(ans);
            return result;
        }

        public HugeInteger remainder(HugeInteger otherNum)
        {
            HugeInteger num1 = new HugeInteger();
            HugeInteger num2 = new HugeInteger();
            HugeInteger result = new HugeInteger(); //Answer
            num1.Input(this.divide(otherNum).multiply(otherNum).ToString()); // First divide by second number round down then multiply by secound number
            num2.Input(this.ToString());
            string ans = num2.subtract(num1).ToString().TrimStart('0');
            if (ans.Equals(""))
            {
                ans = "0";
            }
            result.Input(ans);
            return result;
        }

        public HugeInteger add(HugeInteger otherNum)
        {
            HugeInteger result = new HugeInteger();
            string str1 = this.ToString();
            string str2 = otherNum.ToString();
            if (str1.Length > str2.Length)
            {
                string temp = this.ToString();
                str1 = otherNum.ToString();
                str2 = temp;
            }

            string str = "";

            int diff = str2.Length - str1.Length;

            int carry = 0;

            for (int i = str1.Length - 1; i >= 0; i--)
            {
                int sum = ((char)(str1[i] - '0') + (char)(str2[i + diff] - '0') + carry);
                str += (char)(sum % 10 + '0');
                carry = sum / 10;
            }

            for (int i = str2.Length - str1.Length - 1; i >= 0; i--)
            {
                int sum = ((char)(str2[i] - '0') + carry);
                str += (char)(sum % 10 + '0');
                carry = sum / 10;
            }

            if (carry > 0)
                str += (char)(carry + '0');
            
            char[] ch2 = str.ToCharArray();
            Array.Reverse(ch2);
            string reverse = new string(ch2);
            reverse = reverse.TrimStart('0');
            result.Input(reverse);
            return result;
        }
        public HugeInteger subtract(HugeInteger otherNum)
        {
            HugeInteger result = new HugeInteger();
            string str = "";
            int difference = this.nums.Length - otherNum.nums.Length;
            int carry = 0;

            for (int i = otherNum.nums.Length - 1; i >= 0; i--)
            {
                int sub = nums[i + difference] - otherNum.nums[i] - carry;

                if (sub < 0)
                {
                    sub += 10;
                    carry = 1;
                }
                else
                {
                    carry = 0;
                }

                str += sub.ToString();
            }

            for (int i = nums.Length - otherNum.nums.Length - 1; i >= 0; i--)
            {
                if (nums[i] == 0 && carry > 0)
                {
                    str += "9";
                    continue;
                }
                int sub = nums[i] - carry;
                if (i > 0 || sub > 0)
                {
                    str += sub.ToString();
                }
                carry = 0;
            }
            char[] charArray = str.ToCharArray();
            Array.Reverse(charArray);
            string reverse = new string(charArray);
            result.Input(reverse);
            return result;
        }

        public Boolean isZero()
        {
            HugeInteger zero = new HugeInteger();
            zero.Input("0");

            if (this.isEqualTo(zero))
            {
                return true;
            }
            return false;
        }

        public Boolean isEqualTo(HugeInteger otherNum)
        {
            string str = this.ToString();
            string str1 = otherNum.ToString();
            str = str.TrimStart('0');
            str1 = str1.TrimStart('0');
            if (str.Equals(str1))
            {
                return true;
            }
            return false;
        }

        public Boolean isNotEqualTo(HugeInteger otherNum)
        {
            return !isEqualTo(otherNum);
        }

        public Boolean isGreaterThan(HugeInteger otherNum)
        {
            string str = this.ToString();
            string str1 = otherNum.ToString();
            str = str.TrimStart('0');
            str1 = str1.TrimStart('0');
            if (str.Length > str1.Length)
            {
                return true;
            }
            else if (str.Length < str1.Length)
            {
                return false;
            }
            else
            {
                for (int i = 0; i < str.Length; i++)
                {
                    if (str[i] > str1[i])
                    {
                        return true;
                    }
                    else if (str[i] == str1[i])
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return false;
        }

        public Boolean isLessThan(HugeInteger otherNum)
        {
            if (this.isGreaterThan(otherNum) || this.isEqualTo(otherNum))
            {
                return false;
            }
            return true;
        }

        public Boolean isGreaterThanOrEqualTo(HugeInteger otherNum)
        {
            if (this.isGreaterThan(otherNum) || this.isEqualTo(otherNum))
            {
                return true;
            }
            return false;
        }

        public Boolean isLessThanOrEqualTo(HugeInteger otherNum)
        {
            if (this.isLessThan(otherNum) || this.isEqualTo(otherNum))
            {
                return true;
            }
            return false;
        }

        public static HugeInteger operator +(HugeInteger hugeInteger, string i)
        {
            HugeInteger huge = new HugeInteger();
            huge.Input(i);
            return hugeInteger.add(huge);
        }

        public static HugeInteger operator *(HugeInteger hugeInteger, string i)
        {
            HugeInteger huge = new HugeInteger();
            huge.Input(i);
            return hugeInteger.multiply(huge);
        }
    }
}